var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./GamePadComponent/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./GamePadComponent/index.ts":
/*!***********************************!*\
  !*** ./GamePadComponent/index.ts ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nvar __spreadArrays = this && this.__spreadArrays || function () {\n  for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;\n\n  for (var r = Array(s), k = 0, i = 0; i < il; i++) for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++) r[k] = a[j];\n\n  return r;\n};\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.GamePadComponent = void 0;\n\nvar unique = function unique(value, index, self) {\n  return self.indexOf(value) === index;\n};\n\nvar GamePadComponent =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function GamePadComponent() {\n    this._connected = [];\n    this._pad1Vibrate = 0;\n  }\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  GamePadComponent.prototype.init = function (context, notifyOutputChanged, state, container) {\n    var _this = this;\n\n    this._container = document.createElement(\"div\"); // this._container.setAttribute(\"type\", \"text\");\n\n    this._context = context;\n    this._notifyOutputChanged = notifyOutputChanged; // this._container.addEventListener('change', this.notify.bind(this));\n    // const btn = document.createElement('button');\n    // btn.innerText = \"button\";\n    // btn.addEventListener('click', this.notify.bind(this));\n\n    container.appendChild(this._container); // container.appendChild(btn);\n    // Add control initialization code\n\n    window.addEventListener(\"gamepadconnected\", function (event) {\n      console.log(\"A gamepad connected:\");\n      console.log(event.gamepad);\n      _this._connected = __spreadArrays(_this._connected, [event.gamepad.index]).filter(unique); //this.updateView(context);\n    });\n    window.addEventListener(\"gamepaddisconnected\", function (event) {\n      console.log(\"A gamepad disconnected:\");\n      console.log(event.gamepad);\n      _this._connected = _this._connected.filter(function (value) {\n        return value !== event.gamepad.index;\n      }); //this.updateView(context);\n    });\n    this.tick();\n  };\n\n  GamePadComponent.prototype.pollGamepads = function () {\n    if (navigator.getGamepads) {\n      return navigator.getGamepads();\n    } else {\n      return [];\n    }\n  };\n\n  GamePadComponent.prototype.notify = function () {\n    this._notifyOutputChanged();\n  };\n\n  GamePadComponent.prototype.tick = function () {\n    var _this = this; // Add code to update control view\n\n\n    var gamepads = this.pollGamepads();\n\n    if (gamepads && gamepads.length > 0) {\n      var pads = Object.keys(gamepads).filter(function (key) {\n        return !!gamepads[key];\n      }).map(function (key) {\n        var pad = gamepads[key];\n        return pad;\n      });\n      this._container.innerText = pads.map(function (pad) {\n        return JSON.stringify({\n          axes: pad === null || pad === void 0 ? void 0 : pad.axes,\n          buttons: ((pad === null || pad === void 0 ? void 0 : pad.buttons) || []).map(function (button) {\n            return {\n              pressed: button.pressed,\n              touched: button.touched,\n              value: button.value\n            };\n          }),\n          connected: pad === null || pad === void 0 ? void 0 : pad.connected,\n          id: pad === null || pad === void 0 ? void 0 : pad.id,\n          index: pad === null || pad === void 0 ? void 0 : pad.index\n        });\n      }).join(';'); // // Dispatch it.\n      // var event = new Event('change');\n      // this._container.dispatchEvent(event);\n\n      this._pad1 = pads[0];\n      this.notify();\n      setTimeout(function () {\n        return _this.tick();\n      }, 100); //window.requestAnimationFrame(()=>this.tick());\n    }\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  GamePadComponent.prototype.updateView = function (context) {\n    var vibrate = context.parameters.pad1Vibrate.raw;\n\n    if (vibrate) {\n      this._pad1Vibrate = vibrate;\n\n      if ('vibrationActuator' in this._pad1) {\n        this._pad1.vibrationActuator.playEffect(\"dual-rumble\", {\n          startDelay: 0,\n          duration: this._pad1Vibrate,\n          weakMagnitude: 1.0,\n          strongMagnitude: 1.0\n        });\n      }\n\n      this._pad1Vibrate = 0;\n      this.notify();\n    }\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  GamePadComponent.prototype.getOutputs = function () {\n    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v;\n\n    return {\n      \"pad1Vibrate\": this._pad1Vibrate,\n      \"pad1_0X\": (_a = this._pad1) === null || _a === void 0 ? void 0 : _a.axes[0],\n      \"pad1_0Y\": (_b = this._pad1) === null || _b === void 0 ? void 0 : _b.axes[1],\n      \"pad1_1X\": (_c = this._pad1) === null || _c === void 0 ? void 0 : _c.axes[2],\n      \"pad1_1Y\": (_d = this._pad1) === null || _d === void 0 ? void 0 : _d.axes[3],\n      \"pad1Button0\": (_e = this._pad1) === null || _e === void 0 ? void 0 : _e.buttons[0].value,\n      \"pad1Button1\": (_f = this._pad1) === null || _f === void 0 ? void 0 : _f.buttons[1].value,\n      \"pad1Button2\": (_g = this._pad1) === null || _g === void 0 ? void 0 : _g.buttons[2].value,\n      \"pad1Button3\": (_h = this._pad1) === null || _h === void 0 ? void 0 : _h.buttons[3].value,\n      \"pad1Button4\": (_j = this._pad1) === null || _j === void 0 ? void 0 : _j.buttons[4].value,\n      \"pad1Button5\": (_k = this._pad1) === null || _k === void 0 ? void 0 : _k.buttons[5].value,\n      \"pad1Button6\": (_l = this._pad1) === null || _l === void 0 ? void 0 : _l.buttons[6].value,\n      \"pad1Button7\": (_m = this._pad1) === null || _m === void 0 ? void 0 : _m.buttons[7].value,\n      \"pad1Button8\": (_o = this._pad1) === null || _o === void 0 ? void 0 : _o.buttons[8].value,\n      \"pad1Button9\": (_p = this._pad1) === null || _p === void 0 ? void 0 : _p.buttons[9].value,\n      \"pad1Button10\": (_q = this._pad1) === null || _q === void 0 ? void 0 : _q.buttons[10].value,\n      \"pad1Button11\": (_r = this._pad1) === null || _r === void 0 ? void 0 : _r.buttons[11].value,\n      \"pad1Button12\": (_s = this._pad1) === null || _s === void 0 ? void 0 : _s.buttons[12].value,\n      \"pad1Button13\": (_t = this._pad1) === null || _t === void 0 ? void 0 : _t.buttons[13].value,\n      \"pad1Button14\": (_u = this._pad1) === null || _u === void 0 ? void 0 : _u.buttons[14].value,\n      \"pad1Button15\": (_v = this._pad1) === null || _v === void 0 ? void 0 : _v.buttons[15].value\n    };\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  GamePadComponent.prototype.destroy = function () {// Add code to cleanup control if necessary\n  };\n\n  return GamePadComponent;\n}();\n\nexports.GamePadComponent = GamePadComponent;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./GamePadComponent/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('GamePadNS.GamePadComponent', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.GamePadComponent);
} else {
	var GamePadNS = GamePadNS || {};
	GamePadNS.GamePadComponent = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.GamePadComponent;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}